# phase1_nm
Earthquake Prediction Model using Python
